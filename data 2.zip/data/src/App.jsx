import './App.css';
import React, { useEffect, useState } from 'react';
import Recipe from './components/Recipe';
import { fetchrecipe } from './components/ApiService';



const App = () => {
  const [search, setSearch] = useState('');
  const [allRecipes, setAllRecipes] = useState([]);
  const [filteredRecipes, setFilteredRecipes] = useState([]);
  const [filterTime, setFilterTime] = useState(null); // e.g. 30 for "ready in 30 minutes"
  const [error, setError] = useState('');

  const handleSearch = async () => {
    setError('');
    const data = await fetchrecipe(search);
    if (data) {
      setAllRecipes(data); // save all 50
      setFilteredRecipes(data.slice(0, 10)); // show 10 initially
    } else {
      setFilteredRecipes([]);
      setError('No results found');
    }
  };

  const handleFilterChange = (e) => {
    const time = parseInt(e.target.value);
    setFilterTime(time);
    const filtered = allRecipes.filter(recipe => recipe.readyInMinutes <= time);
    if (filtered.length === 0) {
      setFilteredRecipes([]);
      setError('No results found');
    } else {
      setFilteredRecipes(filtered);
      setError('');
    }
  };


  
  


  

  return (
    <div className="App">
      <h1 className="title">Recipe Finder</h1>
      <input
        type="text"
        className="search"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search for recipes..."
      />
      <button className="searchbutton" onClick={handleSearch}>Search</button>

      {allRecipes.length > 0 && (
        <div className="filter">
          <label>Max Ready Time (mins): </label>
          <select onChange={handleFilterChange}>
            <option value="">--Select--</option>
            <option value="10">10</option>
            <option value="20">20</option>
            <option value="30">30</option>
            <option value="45">45</option>
            <option value="60">60</option>
          </select>
        </div>
      )}

      {error && <p>{error}</p>}

        <div className="info">

      

          <div className="recipes-grid">
            {filteredRecipes.map((r) => (
              <Recipe key={r.id} id={r.id} />
            ))}
          </div>

          
          
            

              
        

        
        </div>

      
    </div>
  );
};

export default App;
