import React, { useState, useEffect } from "react";
import { fetchInfo } from "./ApiService";
import { Link} from "react-router-dom";

const Recipe = ({ id }) => {
  const [info, setInfo] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      const recipeInfo = await fetchInfo(id);
      if (recipeInfo) {
        setInfo(recipeInfo);
      } else {
        console.error('No valid recipe data found');
      }
    };
    fetchData();
  }, [id]);

  if (!info) return <div className="loading">Loading...</div>;

  const { image, title, readyInMinutes, sourceUrl, sourceName } = info;

  return (
   
    
      <div className="recipeCard">
        <img src={image} alt={title} />
        <h2>{title}</h2>
        <p>Source: {sourceName}</p>
        <p>Ready in {readyInMinutes} minutes</p>
        <Link className="link" to={`/recipeDetails/${id}`}>View Recipe</Link>
      </div>
    
  );
};

export default Recipe;
