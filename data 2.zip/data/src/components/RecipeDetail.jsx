import React, {Component, useEffect, useState} from "react";
import {useParams} from "react-router-dom";
import {fetchInfo} from "../components/ApiService";

const API_KEY = import.meta.env.VITE_API_KEY;



const RecipeDetail = () => {
    const {id} = useParams();
    const [info, setInfo] = useState(null);

    useEffect(() => {
        const loadInfo = async () => {
            const data = await fetchInfo(id);
            setInfo(data);
        }

        loadInfo();
    }, [id]);

    if (!info) return <div className="loading">Loading...</div>;

    const nutrition = info.nutrition?.nutrients || [];

    const getNutrient = name => {
        return nutrition.find((n) => n.name === name);
    };

    const calories = getNutrient("Calories");
    const protein = getNutrient("Protein");
    const fat = getNutrient("Fat");
    const carbs = getNutrient("Carbohydrates");
    const vitaminC = getNutrient("Vitamin C");
    const vitaminA = getNutrient("Vitamin A");


    return(
        <div className="details">
    
            <h1>{info.title}</h1>
            <img src={info.image} alt={info.title} />
            <p>Ready in: {info.readyInMinutes} minutes</p>

            <h2>Nurtritional Info (per serving)</h2>

            <ul>
                <li><strong>Calories:</strong> {calories?.amount} {calories?.unit}</li>
                <li><strong>Protein:</strong> {protein?.amount} {protein?.unit}</li>
                <li><strong>Carbohydrates:</strong> {carbs?.amount} {carbs?.unit}</li>
                <li><strong>Fat:</strong> {fat?.amount} {fat?.unit}</li>
                <li><strong>Vitamin C:</strong> {vitaminC?.amount} {vitaminC?.unit}</li>
                <li><strong>Vitamin A:</strong> {vitaminA?.amount} {vitaminA?.unit}</li>
            </ul>

        
        </div>
        
    )

}


export default RecipeDetail;