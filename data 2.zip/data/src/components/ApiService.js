export async function fetchrecipe(search) {
    const response = await fetch(`https://api.spoonacular.com/recipes/complexSearch?query=${search}&number=50&apiKey=15062c6980e14d56850c6d691ac9dbb5&addRecipeInformation=true`);
    const data = await response.json();
    return data.results.length > 0 ? data.results : null; // Return null if no valid data
}

export async function fetchInfo(id) {
    const response = await fetch(`https://api.spoonacular.com/recipes/${id}/information?apiKey=15062c6980e14d56850c6d691ac9dbb5&includeNutrition=true`);
    const data = await response.json();
    return data; // Return null if no valid data
}