import RecipeDetail from "../src/components/RecipeDetail";

const DetailView = () => {

return(
    <>
        <RecipeDetail/>
    </>
)


}

export default DetailView;